using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScripts : MonoBehaviour
{   
    public AudioClip Sound;
    public float Speed;

    private Rigidbody2D Rigidbody2D;
    private Vector2 Direction;
    
    
    void Start()
    {
        Rigidbody2D = GetComponent<Rigidbody2D>();
        //Camera.main.GetComponent<AudioSource>().PlayShot;
        Camera.main.GetComponent<AudioSource>().Play();
    
    }

    
    private void FixedUpdate()
    {
        Rigidbody2D.velocity = Direction * Speed;
    }

    public void SetDirection(Vector2 newDirection)
    {
        Direction = newDirection;
    }

    public void DestroyBullet()
        {
            Destroy(gameObject);
        }
         private void OnTriggerEnter2D(Collider2D collision)
         {
            jhonmovement Jhon = collision.GetComponent<jhonmovement>();
            GruntScript grunt = collision.GetComponent<GruntScript>();            
            if (Jhon != null)
            {
                Jhon.Hit();
            }
            if (grunt != null)
            {
                grunt.Hit();
            }
            DestroyBullet();
         }
}
